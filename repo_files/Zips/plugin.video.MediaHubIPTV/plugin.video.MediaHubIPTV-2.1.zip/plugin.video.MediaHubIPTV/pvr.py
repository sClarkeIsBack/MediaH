import json
import xbmc, xbmcgui, xbmcaddon

def pvr():
	jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":%s},"id":1}'
	jsonNotify = '{"jsonrpc":"2.0", "method":"GUI.ShowNotification", "params":{"title":"PVR", "message":"%s","image":""}, "id":1}'
	if not control.condVisibility('Pvr.HasTVChannels'):
		xbmc.executeJSONRPC(jsonSetPVR % "true")
		xbmc.executeJSONRPC(jsonNotify % "Live TV Enabled")